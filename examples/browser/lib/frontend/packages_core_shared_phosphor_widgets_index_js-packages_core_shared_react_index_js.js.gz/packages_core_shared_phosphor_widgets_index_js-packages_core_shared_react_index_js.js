(self["webpackChunk_theia_example_browser"] = self["webpackChunk_theia_example_browser"] || []).push([["packages_core_shared_phosphor_widgets_index_js-packages_core_shared_react_index_js"],{

/***/ "../../packages/core/shared/@phosphor/widgets/index.js":
/*!*************************************************************!*\
  !*** ../../packages/core/shared/@phosphor/widgets/index.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! @phosphor/widgets */ "../../node_modules/@phosphor/widgets/lib/index.js");

;(globalThis['theia'] = globalThis['theia'] || {})['@theia/core/shared/@phosphor/widgets'] = this;


/***/ }),

/***/ "../../packages/core/shared/react/index.js":
/*!*************************************************!*\
  !*** ../../packages/core/shared/react/index.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

;(globalThis['theia'] = globalThis['theia'] || {})['@theia/core/shared/react'] = this;


/***/ })

}]);
//# sourceMappingURL=packages_core_shared_phosphor_widgets_index_js-packages_core_shared_react_index_js.js.map