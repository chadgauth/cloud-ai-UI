(self["webpackChunk_theia_example_browser"] = self["webpackChunk_theia_example_browser"] || []).push([["packages_core_shared_theia_application-package_lib_environment_index_js-packages_core_shared_-8369120"],{

/***/ "../../packages/core/shared/@theia/application-package/lib/environment/index.js":
/*!**************************************************************************************!*\
  !*** ../../packages/core/shared/@theia/application-package/lib/environment/index.js ***!
  \**************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! @theia/application-package/lib/environment */ "../../dev-packages/application-package/lib/environment.js");

;(globalThis['theia'] = globalThis['theia'] || {})['@theia/core/shared/@theia/application-package/lib/environment'] = this;


/***/ }),

/***/ "../../packages/core/shared/react/index.js":
/*!*************************************************!*\
  !*** ../../packages/core/shared/react/index.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! react */ "../../node_modules/react/index.js");

;(globalThis['theia'] = globalThis['theia'] || {})['@theia/core/shared/react'] = this;


/***/ })

}]);
//# sourceMappingURL=packages_core_shared_theia_application-package_lib_environment_index_js-packages_core_shared_-8369120.js.map